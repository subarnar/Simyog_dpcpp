#include <CL/sycl.hpp>
#include <iostream>
#define N 1024
using namespace cl::sycl;
//using namespace std;
int main() {

    float A[N], B[N], C[N];
    
    for (int i = 0; i < N; i++){
                A[i] = i;
                B[i] = i;
                C[i] = 0;
        }

    {
        //Add your DPCPP code
    }
        for (int i = 0; i < 5; i++){
        std::cout << "A[" << i << "] = " << A[i] <<std::endl;
        std::cout << "B[" << i << "] = " << B[i] <<std::endl;
        std::cout << "C[" << i << "] = " << C[i] <<std::endl;
    }
    return 0;
}